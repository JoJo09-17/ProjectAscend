﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "AscendAbilityFragment.h"


#include UE_INLINE_GENERATED_CPP_BY_NAME(AscendAbilityFragment)
