﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "UObject/Object.h"
#include "AscendAbilityFragment.generated.h"

/**
 * 
 */
UCLASS(DefaultToInstanced, EditInlineNew, Abstract, Blueprintable, BlueprintType)
class PROJECTASCEND_API UAscendAbilityFragment : public UObject
{
	GENERATED_BODY()
	
public:
	
protected:
	
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ascend|Fragment|Identify")
	FGameplayTag FragmentTag;
	
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Ascend|Fragment|Identify")
	FGameplayTagContainer FragmentDynamicTags;
};
