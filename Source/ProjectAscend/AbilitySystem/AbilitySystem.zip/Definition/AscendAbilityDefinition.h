﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AscendDefinition.h"
#include "GameplayTagContainer.h"
#include "ScalableFloat.h"
#include "AscendAbilityDefinition.generated.h"

class UAscendGameplayAbility;
UCLASS()
class PROJECTASCEND_API UAscendAbilityDefinition : public UAscendDefinition
{
	GENERATED_BODY()
	
public:
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ascend|Definition")
	TSubclassOf<UAscendGameplayAbility> Ability = nullptr;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ascend|Definition")
	int32 DefaultLevel = 1;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly,Meta = (Categories = "InputTag"), Category = "Ascend|Definition")
	FGameplayTag InputTag;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ascend|Definition", Meta = (Categories = "Ability"))
	FGameplayTagContainer AbilityTag;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ascend|Definition")
	FGameplayTagContainer OwnedTags;
	
	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Ascend|Definition")
	FScalableFloat CooldownDuration;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ascend|Definition", Meta = (Categories = TAG_Gameplay_CoolDown))
	FGameplayTagContainer CooldownTags;
};
