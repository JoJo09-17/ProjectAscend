﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AbilitySystem/Fragments/AscendAbilityFragment.h"
#include "Engine/DataAsset.h"
#include "AscendDefinition.generated.h"


UCLASS()
class PROJECTASCEND_API UAscendDefinition : public UPrimaryDataAsset
{
	GENERATED_BODY()
	
public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Instanced, Category="Ascend|Fragments")
	TArray<TObjectPtr<UAscendAbilityFragment>> Fragments;
	
	UFUNCTION(BlueprintCallable, BlueprintPure = false, meta = (DeterminesOutputType = FragmentClass), Category = "Ascend|Fragments")
	UAscendAbilityFragment* FindFragmentByClass(TSubclassOf<UAscendAbilityFragment> FragmentClass) const;
	
	
	template <typename ResultClass>
	const ResultClass* FindFragmentByClass() const
	{
		return (ResultClass*)FindFragmentByClass(ResultClass::StaticClass());
	}
};
