﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "AscendDefinition.h"

#include "AbilitySystem/Fragments/AscendAbilityFragment.h"


#include UE_INLINE_GENERATED_CPP_BY_NAME(AscendDefinition)

UAscendAbilityFragment* UAscendDefinition::FindFragmentByClass(
	TSubclassOf<UAscendAbilityFragment> FragmentClass) const
{
	if (FragmentClass != nullptr)
	{
		for (UAscendAbilityFragment* Fragment : Fragments)
		{
			if (Fragment && Fragment->IsA(FragmentClass))
			{
				return Fragment;
			}
		}
	}
	return nullptr;
}
