﻿
#include "AscendAbilitySet.h"
#include "AbilitySystemLog.h"
#include "AbilitySystem/AscendAbilitySystemComponent.h"
#include "AbilitySystem/Definition/AscendAbilityDefinition.h"


#include UE_INLINE_GENERATED_CPP_BY_NAME(AscendAbilityFragment)

UAscendAbilitySet::UAscendAbilitySet(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{
	
}

void UAscendAbilitySet::GiveToRPGAbilitySystem(UAscendAbilitySystemComponent* ASC,
	FAscendAbilitySet_GrantedHandles* OutGrantedHandles, UObject* SourceObject) const
{
	check(ASC);

	if (!ASC->IsOwnerActorAuthoritative())
	{
		return;
	}
	
	for (int32 AscendAbilityIndex = 0; AscendAbilityIndex < GrantedGameplayAbilities.Num(); ++AscendAbilityIndex)
	{
		if (!GrantedGameplayAbilities[AscendAbilityIndex])
		{
			UE_LOG(LogAbilitySystem, Error, TEXT("GrantedGameplayAbilities[%d] on ability set [%s] is not valid."), AscendAbilityIndex, *GetNameSafe(this));
			continue;
		}
		
		if (!GrantedGameplayAbilities[AscendAbilityIndex]->Ability)
		{
			UE_LOG(LogAbilitySystem, Error, TEXT("Abilitiy[%d] on ability set [%s] is not valid."), AscendAbilityIndex, *GetNameSafe(this));
			continue;
		}
		
		UAscendGameplayAbility* AbilityCDO = GrantedGameplayAbilities[AscendAbilityIndex]->Ability->GetDefaultObject<UAscendGameplayAbility>();
		
		if (!AbilityCDO)
		{
			UE_LOG(LogAbilitySystem, Error, TEXT("GrantedGameplayAbilities[%d] on ability set [%s] is not RPGGameplayAbility."), AscendAbilityIndex, *GetNameSafe(this));
			continue;
		}
		
		FGameplayAbilitySpec AbilitySpec(AbilityCDO, GrantedGameplayAbilities[AscendAbilityIndex]->DefaultLevel);
		AbilitySpec.SourceObject = SourceObject;
		
		if (GrantedGameplayAbilities[AscendAbilityIndex]->InputTag.IsValid())
		{
			AbilitySpec.GetDynamicSpecSourceTags().AddTag(GrantedGameplayAbilities[AscendAbilityIndex]->InputTag);
		}
		
		if (UAscendAbilitySystemComponent* AscendASC = Cast<UAscendAbilitySystemComponent>(ASC))
		{
			const FGameplayAbilitySpecHandle AbilitySpecHandle = AscendASC->GiveAscendAbility(AbilitySpec, GrantedGameplayAbilities[AscendAbilityIndex]);
			
			if (OutGrantedHandles)
			{
				OutGrantedHandles->AddAbilitySpecHandle(AbilitySpecHandle);
			}
		}
		else
		{
			UE_LOG(LogAbilitySystem, Error, TEXT("GrantedGameplayAbilities[%d] on ability set [%s] is not Instance."), AscendAbilityIndex, *GetNameSafe(this));
			continue;
		}
	}
	
	for (int32 AbilityIndex = 0; AbilityIndex < GrantedGameplayAbilities.Num(); ++AbilityIndex)
	{
		const FAscendAbilitySet_GameplayAbility& AbilityToGrant = GrantedGameplayAbilities[AbilityIndex];
		
		if (!IsValid(AbilityToGrant.Ability))
		{
			UE_LOG(LogAbilitySystem, Error, TEXT("GrantedGameplayAbilities[%d] on ability set [%s] is not valid."), AbilityIndex, *GetNameSafe(this));
			continue;
		}
		
		UGameplayAbility* AbilityCDO = AbilityToGrant.Ability->GetDefaultObject<UGameplayAbility>();

		FGameplayAbilitySpec AbilitySpec(AbilityCDO, AbilityToGrant.AbilityLevel);
		AbilitySpec.SourceObject = SourceObject;
		AbilitySpec.GetDynamicSpecSourceTags().AddTag(AbilityToGrant.InputTag);
		
		const FGameplayAbilitySpecHandle AbilitySpecHandle = ASC->GiveAbility(AbilitySpec);

		if (OutGrantedHandles)
		{
			OutGrantedHandles->AddAbilitySpecHandle(AbilitySpecHandle);
		}
	}

	for (int32 SetIndex = 0; SetIndex < GrantedAttributes.Num(); ++SetIndex)
	{
		const FAscendAbilitySet_AttributeSet& SetToGrant = GrantedAttributes[SetIndex];
		
		if (!IsValid(SetToGrant.AttributeSet))
		{
			UE_LOG(LogAbilitySystem, Error, TEXT("GrantedAttributes[%d] on ability set [%s] is not valid"), SetIndex, *GetNameSafe(this));
			continue;
		}
		
		UAttributeSet* NewSet = NewObject<UAttributeSet>(ASC->GetOwner(), SetToGrant.AttributeSet);
		ASC->AddAttributeSetSubobject(NewSet);

		if (OutGrantedHandles)
		{
			OutGrantedHandles->AddAttributeSet(NewSet);
		}
	}

	for (int32 EffectIndex = 0; EffectIndex < GrantedGameplayEffects.Num(); ++EffectIndex)
	{
		const FAscendAbilitySet_GameplayEffect& EffectToGrant = GrantedGameplayEffects[EffectIndex];
		
		if (!IsValid(EffectToGrant.GameplayEffect))
		{
			UE_LOG(LogAbilitySystem, Error, TEXT("GrantedGameplayEffects[%d] on ability set [%s] is not valid"), EffectIndex, *GetNameSafe(this));
			continue;
		}
		
		const UGameplayEffect* GameplayEffect = EffectToGrant.GameplayEffect->GetDefaultObject<UGameplayEffect>();
		const FActiveGameplayEffectHandle GameplayEffectHandle = ASC->ApplyGameplayEffectToSelf(GameplayEffect, EffectToGrant.EffectLevel, ASC->MakeEffectContext());

		if (OutGrantedHandles)
		{
			OutGrantedHandles->AddGameplayEffectHandle(GameplayEffectHandle);
		}
	}
}
