// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ActiveGameplayEffectHandle.h"
#include "AttributeSet.h"
#include "GameplayTagContainer.h"
#include "Logging/LogMacros.h"
#include "GameplayAbilitySpecHandle.h"
#include "Engine/DataAsset.h"
#include "AscendAbilitySet.generated.h"

class UGameplayAbility;
class UGameplayEffect;
class UAscendAbilityDefinition;
class UAscendAbilitySystemComponent;
/**
 * Configures abilities that can be assigned to an avatar.
 */

USTRUCT(BlueprintType)
struct FAscendAbilitySet_GameplayAbility
{
	GENERATED_BODY()

public:

	UPROPERTY(EditDefaultsOnly, Category = "Ascend|AbilitySet")
	TSubclassOf<UGameplayAbility> Ability = nullptr;
	
	UPROPERTY(EditDefaultsOnly, Category = "Ascend|AbilitySet")
	int32 AbilityLevel = 1;
	
	UPROPERTY(EditDefaultsOnly, Category = "Ascend|AbilitySet", Meta = (Categories = "InputTag"))
	FGameplayTag InputTag;
};

USTRUCT(BlueprintType)
struct FAscendAbilitySet_GameplayEffect
{
	GENERATED_BODY()

public:
	
	UPROPERTY(EditDefaultsOnly, Category = "Ascend|AbilitySet")
	TSubclassOf<UGameplayEffect> GameplayEffect = nullptr;
	
	UPROPERTY(EditDefaultsOnly, Category = "Ascend|AbilitySet")
	float EffectLevel = 1.0f;
};

USTRUCT(BlueprintType)
struct FAscendAbilitySet_AttributeSet
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, Category = "Ascend|AbilitySet")
	TSubclassOf<UAttributeSet> AttributeSet;
};


USTRUCT(BlueprintType)
struct FAscendAbilitySet_GrantedHandles
{
	GENERATED_BODY()

public:
	
	void AddAbilitySpecHandle(const FGameplayAbilitySpecHandle& Handle);
	
	void AddGameplayEffectHandle(const FActiveGameplayEffectHandle& Handle);
	
	void AddAttributeSet(UAttributeSet* Set);
	
	void TakeFromAbilitySystem(UAscendAbilitySystemComponent* RPGASC);

protected:
	UPROPERTY()
	TArray<FGameplayAbilitySpecHandle> AbilitySpecHandles;

	UPROPERTY()
	TArray<FActiveGameplayEffectHandle> GameplayEffectHandles;
	
	UPROPERTY()
	TArray<TObjectPtr<UAttributeSet>> GrantedAttributeSets;
};

UCLASS()
class PROJECTASCEND_API UAscendAbilitySet : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:

	/** Asset type that uniquely identifies this data asset. */
	static FPrimaryAssetType AssetType;	
	
	UAscendAbilitySet(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
	
	void GiveToRPGAbilitySystem(UAscendAbilitySystemComponent* ASC, FAscendAbilitySet_GrantedHandles* OutGrantedHandles, UObject* SourceObject = nullptr) const /*override*/;
	
	UFUNCTION(BlueprintCallable, Category = "AdvancedGASSystem|AbilitySet", meta = (DisplayName = "GiveToAbilitySystem"))
	void BP_GiveToAbilitySystem(UAscendAbilitySystemComponent* ASC, struct FAscendAbilitySet_GrantedHandles& OutGrantedHandles, UObject* SourceObject = nullptr);
	
	UFUNCTION(BlueprintCallable, Category = "AdvancedGASSystem|AbilitySet", meta = (DisplayName = "TakeFromAbilitySystem"))
	static void BP_TakeFromAbilitySystem(UAscendAbilitySystemComponent* ASC, FAscendAbilitySet_GrantedHandles GrantedHandles);
	
	UPROPERTY(EditDefaultsOnly, Category = "Ascend|AbilitySet", meta = (TitleProperty = Ability))
	TArray<TObjectPtr<UAscendAbilityDefinition>> GrantedGameplayAbilities;
	
	UPROPERTY(EditDefaultsOnly, Category = "Ascend|AbilitySet", meta = (TitleProperty = Ability))
	TArray<FAscendAbilitySet_GameplayAbility> GrantedDefaultGameplayAbilities;
	
	UPROPERTY(EditDefaultsOnly, Category = "Ascend|AbilitySet", meta = (TitleProperty = GameplayEffect))
	TArray<FAscendAbilitySet_GameplayEffect> GrantedGameplayEffects;
	
	UPROPERTY(EditDefaultsOnly, Category = "Ascend|AbilitySet", meta = (TitleProperty = AttributeSet))
	TArray<FAscendAbilitySet_AttributeSet> GrantedAttributes;
};
